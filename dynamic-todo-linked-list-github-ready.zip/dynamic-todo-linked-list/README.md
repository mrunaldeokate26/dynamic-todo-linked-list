# Dynamic To-Do List Manager Using a Singly Linked List

A browser-based, interactive demonstration of a to-do list managed with a singly linked list. The interface visualizes each node, its `next` pointer, the head pointer, and a table of tasks.

> **Implementation note:** The attached project is a single-page HTML application using JavaScript, Tailwind CSS (loaded from a CDN), and simulated heap addresses. It demonstrates linked-list behavior in the browser; it is **not a C implementation**, and the displayed addresses are not real memory addresses from `malloc()`.

## Features

- Add tasks with a description, due date, and due time
- Append new nodes to the tail of the linked list
- View the list from `head` to `NULL`
- See each node's ID, simulated address, and `next` pointer
- Delete a task and re-index the remaining tasks
- Load a sample task
- Clear the complete list
- Responsive dark interface with status notifications

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a modern browser.
3. No build step is required.

The interface loads Tailwind CSS and Google Fonts from CDNs, so an internet connection is needed for those external assets. The core HTML and JavaScript are in `index.html`.

## How the linked list works

Each task is represented by a node containing:

- `id`: task number
- `description`: task text
- `date` and `time`: optional due date and time
- `address`: a simulated address for visualization
- `next`: reference to the next node, or `null` for the last node

The `head` variable points to the first node. Appending traverses the list until the final node, then links the new node. Deleting a node updates either `head` or the previous node's `next` reference.

## Complexity

| Operation | Time complexity | Notes |
|---|---:|---|
| Add task to tail | O(n) | Traverses the list to find the last node |
| Delete task by ID | O(n) | May traverse the list to locate the task |
| Display/traverse list | O(n) | Visits each node once |
| Clear list | O(1) | Resets `head` to `null` in this JavaScript demo |

## Project structure

```text
dynamic-todo-linked-list/
├── index.html   # Complete interactive application
├── README.md    # Project overview and run instructions
├── LICENSE      # MIT License
└── .gitignore   # Common local/editor files to ignore
```

## Technologies

- HTML5
- JavaScript (classes, objects, DOM events)
- Tailwind CSS via CDN
- Google Fonts via CDN

## Author

**Mrunal Prafull Deokate**  
Registration No.: 2502051945

## Future improvements

- Persist tasks using `localStorage` or a database
- Add edit-task and completion-status features
- Add search and sorting
- Create a separate C console implementation using actual `malloc()` and `free()` if required for a C/DSA submission

## License

This project is available under the MIT License. See `LICENSE`.
